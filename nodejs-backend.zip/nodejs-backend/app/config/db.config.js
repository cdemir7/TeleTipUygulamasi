module.exports = {
    HOST: "hastanedb",
    USER: "db_user",
    PASSWORD: "123",
    DB: "DB_HASTANE_TELETIP"
  };
